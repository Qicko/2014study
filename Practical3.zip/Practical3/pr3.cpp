// ��3.cpp : Defines the entry point for the console application.
//

#include <iostream>

extern "C"{
	extern int getResult( int x, int y, int z );
}

int main()
{
	int x, y, z;
	int result;
	std::cin >> x >> y >> z;
	result = getResult( x, y, z);
	std::cout << result << std::endl;
	return 0;
}

